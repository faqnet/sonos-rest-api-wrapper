class Music_serive_account:

    def __init__(self, id , user_id_hash_code, is_guest, service):
        self.id = id
        self.user_id_hash_code = user_id_hash_code
        self.is_guets = is_guest
        self.service = service
