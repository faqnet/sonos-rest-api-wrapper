
class Favourite:

    def __init__ (self, id, name, description, image_url):
        self.id = id
        self.name = name
        self.description = description
        self.image_url = image_url
